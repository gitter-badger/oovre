(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.less = {};

})();

//# sourceMappingURL=less.js.map
