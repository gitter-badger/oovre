(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/wylio:mandrill/mandrill.js                                                           //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
Meteor.Mandrill = {                                                                              // 1
    config: function (options) {                                                                 // 2
        var host, key, port, username;                                                           // 3
        username = options["username"];                                                          // 4
        key = options["key"];                                                                    // 5
        host = "smtp.mandrillapp.com";                                                           // 6
        port = "587";                                                                            // 7
        process.env.MAIL_URL = "smtp://" + username + ":" + key + "@" + host + ":" + port + "/"; // 8
    },                                                                                           // 9
    send: function (options) {                                                                   // 10
        Email.send(options);                                                                     // 11
    },                                                                                           // 12
    sendTemplate: function (options) {                                                           // 13
        var url = "https://mandrillapp.com/api/1.0/messages/send-template.json",                 // 14
            result;                                                                              // 15
                                                                                                 // 16
        options = {                                                                              // 17
            "data": {                                                                            // 18
                "key": options.key,                                                              // 19
                "template_name": options.template_name,                                          // 20
                "template_content": options.template_content,                                    // 21
                "message": options.message,                                                      // 22
                "headers": [{                                                                    // 23
                    "Content-Type": "application/json"                                           // 24
                }]                                                                               // 25
            }                                                                                    // 26
        };                                                                                       // 27
                                                                                                 // 28
        try {                                                                                    // 29
            result = HTTP.post(url, options);                                                    // 30
        } catch (e) {                                                                            // 31
            console.log(e.stack);                                                                // 32
        }                                                                                        // 33
                                                                                                 // 34
    }                                                                                            // 35
};                                                                                               // 36
                                                                                                 // 37
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['wylio:mandrill'] = {};

})();

//# sourceMappingURL=wylio_mandrill.js.map
