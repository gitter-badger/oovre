(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['codepoet:medium-editor-npm'] = {};

})();

//# sourceMappingURL=codepoet_medium-editor-npm.js.map
