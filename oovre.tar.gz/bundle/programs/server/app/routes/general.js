(function(){Router.route('/', { name: 'home' });
Router.route('/account/edit', { name: 'editAccount' });

})();
