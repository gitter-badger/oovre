(function(){Comments = new Mongo.Collection('comments');

})();
