(function(){Growls = new Mongo.Collection('growls');

})();
